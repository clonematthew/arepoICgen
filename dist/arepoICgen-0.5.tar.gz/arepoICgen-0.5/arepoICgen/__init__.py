from .generateICs import generateICs
from .generateICs import easySphere